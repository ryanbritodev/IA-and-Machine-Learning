# config.py
# Configurações globais e mapeamento de componentes HTML (Seletores)

CONFIG = {
    "url_jornada": "https://canal360i.cloud.itau.com.br/painel/wrapper/999/jornada-precificacao",
    "timeout_padrao_ms": 15000,
    "headless": False,
}

# SELETORES (Dicionários para fácil parametrização por Analistas de Negócio)
SELETORES = {
    "CAMPO_BUSCA": [
        'input[name="buscaCliente"]',
        'input[placeholder="Buscar por CNPJ raiz"]'
    ],
    "CARD_EMPRESA": [
        'div[data-testid="card-grupo-resumo"]',
        ".busca-cliente__card-grupo"
    ],
    "BOTAO_CONTINUAR": [
        'button:has-text("Continuar")'
    ],
    "PRODUTO_DESCONTO": [
        'button.produtos-categorias__card:has-text("Desconto")'
    ],
    "PRODUTO_COBRANCA": [
        'button.produtos-categorias__card:has-text("Cobrança")' # Exemplo para outro produto
    ],
    "CAMPO_VALOR_CLIENTE": [
        'input[name="valorCliente"]'
    ],
    "BOTAO_PRECIFICAR": [
        'button.ids-main-button:has-text("Precificar")'
    ],
    "BOTAO_ADICIONAR_CARRINHO": [
        'button.ids-main-button:has-text("Adicionar")'
    ]
}
