# gui.py
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

class AutoHomologGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Auto Homolog - Construtor de Jornadas Modulares")
        self.root.geometry("800x500")
        self.root.configure(padx=20, pady=20)
        
        # Variáveis
        self.produto_var = tk.StringVar(value="Desconto")
        self.arquivo_var = tk.StringVar(value="massa_teste.xlsx")
        
        self.criar_widgets()
        
    def criar_widgets(self):
        # Cabeçalho
        lbl_titulo = tk.Label(self.root, text="Parametrização de Lote Automático", font=("Arial", 16, "bold"))
        lbl_titulo.pack(pady=(0, 20))
        
        # Frame Configurações
        frame_config = tk.LabelFrame(self.root, text="Configurações", padx=10, pady=10)
        frame_config.pack(fill="x", pady=10)
        
        tk.Label(frame_config, text="Produto Alvo:").grid(row=0, column=0, sticky="w")
        cb_produto = ttk.Combobox(frame_config, textvariable=self.produto_var, values=["Desconto", "Cobrança", "CG"])
        cb_produto.grid(row=0, column=1, padx=10)
        cb_produto.bind("<<ComboboxSelected>>", self.atualizar_blocos)
        
        tk.Label(frame_config, text="Arquivo de Massa (.xlsx):").grid(row=1, column=0, sticky="w", pady=10)
        tk.Entry(frame_config, textvariable=self.arquivo_var, width=40).grid(row=1, column=1, padx=10)
        tk.Button(frame_config, text="Procurar...", command=self.procurar_arquivo).grid(row=1, column=2)
        
        # Frame Construtor de Blocos
        frame_blocos = tk.LabelFrame(self.root, text="Fluxo de Execução (Blocos Lógicos)", padx=10, pady=10)
        frame_blocos.pack(fill="both", expand=True)
        
        lbl_info = tk.Label(frame_blocos, text="Abaixo estão os blocos que compõem a jornada do produto selecionado. Analistas podem visualizar a ordem.", fg="#555")
        lbl_info.pack(anchor="w")
        
        self.lista_blocos = tk.Listbox(frame_blocos, height=8, font=("Consolas", 11))
        self.lista_blocos.pack(fill="both", expand=True, pady=10)
        self.atualizar_blocos()
        
        # Frame Botões
        frame_botoes = tk.Frame(self.root)
        frame_botoes.pack(fill="x", pady=10)
        
        btn_executar = tk.Button(frame_botoes, text="Executar Lote", bg="#EC7000", fg="white", font=("Arial", 12, "bold"), command=self.executar)
        btn_executar.pack(side="right", padx=10)
        
    def procurar_arquivo(self):
        filename = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if filename:
            self.arquivo_var.set(filename)
            
    def atualizar_blocos(self, event=None):
        self.lista_blocos.delete(0, tk.END)
        prod = self.produto_var.get()
        if prod == "Desconto":
            blocos = ["[BLOCO] Buscar CNPJ e Selecionar Empresa", "[BLOCO] Selecionar Produto: Desconto", "[BLOCO] Preencher Modalidade e Valor", "[BLOCO] Precificar", "[BLOCO] Adicionar ao Carrinho"]
        elif prod == "Cobrança":
            blocos = ["[BLOCO] Buscar CNPJ e Selecionar Empresa", "[BLOCO] Selecionar Produto: Cobrança", "[BLOCO] Configurar Tarifas", "[BLOCO] Confirmar Inclusão"]
        else:
            blocos = ["[BLOCO] Buscar CNPJ...", "[BLOCO] Parametrizar CG..."]
            
        for b in blocos:
            self.lista_blocos.insert(tk.END, " ➔ " + b)
            
    def executar(self):
        messagebox.showinfo("Execução", f"Iniciando automação para o produto: {self.produto_var.get()}\n\nAbra o terminal para ver os logs da simulação modular.")
        # Aqui chamaria o main.py real em uma thread separada.
        
if __name__ == "__main__":
    root = tk.Tk()
    app = AutoHomologGUI(root)
    root.mainloop()
