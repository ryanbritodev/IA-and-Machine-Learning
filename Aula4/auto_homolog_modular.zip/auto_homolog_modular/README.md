# Auto Homolog - Arquitetura Modular

Esta é a proposta de refatoração do script original de precificação para uma **Arquitetura Modular em Blocos**.

## Como funciona?

1. **`core/actions.py`**: Contém funções puramente didáticas e reutilizáveis, como `apertar_botao(seletor)` e `inputar_valor(seletor, valor)`. Elas encapsulam as complexidades de espera (wait) e tratamento de erros.
2. **`config.py`**: Todos os seletores HTML (como ids e classes) ficam aqui. Se o frontend mudar, o Analista de Negócios altera o texto aqui, sem tocar na lógica do Python.
3. **`produtos/`**: Cada produto tem seu próprio arquivo (ex: `desconto.py`, `cobranca.py`). Dentro deles, criamos "Blocos Lógicos" (funções curtas) que agrupam ações. 
4. **`produtos/base.py`**: O motor `JornadaModular` empilha esses blocos em ordem e os executa de forma segura.
5. **`gui.py`**: Uma Interface Gráfica simples feita em Tkinter. Permite que o analista escolha o Produto, veja quais blocos serão executados e inicie o teste.

## Como testar
1. Instale dependências: `pip install playwright pandas`
2. Instale o navegador: `playwright install chromium`
3. Execute a interface: `python gui.py`
