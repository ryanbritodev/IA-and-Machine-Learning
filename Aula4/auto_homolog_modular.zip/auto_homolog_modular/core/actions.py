# core/actions.py
import time
import logging
from playwright.sync_api import Page, Locator, TimeoutError as PlaywrightTimeoutError

LOG = logging.getLogger("actions")

def aguardar_rede_ociosa(page: Page, timeout_ms: int = 2000):
    try:
        page.wait_for_load_state("networkidle", timeout=timeout_ms)
    except:
        pass

def obter_elemento(page: Page, seletores: list, timeout_ms: int = 15000) -> Locator:
    """Tenta encontrar o primeiro seletor válido da lista."""
    step = 200
    elapsed = 0
    while elapsed < timeout_ms:
        for seletor in seletores:
            try:
                el = page.locator(seletor).first
                if el.is_visible():
                    return el
            except:
                pass
        time.sleep(step / 1000.0)
        elapsed += step
    raise RuntimeError(f"Nenhum dos seletores foi encontrado: {seletores}")

def apertar_botao(page: Page, identificadores_html: list, nome_botao: str = ""):
    """Função didática para clicar em um botão."""
    LOG.info(f"Apertando botão: {nome_botao}")
    elemento = obter_elemento(page, identificadores_html)
    elemento.scroll_into_view_if_needed()
    try:
        elemento.click(timeout=5000)
    except:
        elemento.click(force=True)
    aguardar_rede_ociosa(page)

def inputar_valor(page: Page, identificadores_html: list, valor: str, nome_campo: str = ""):
    """Função didática para digitar valores em campos."""
    LOG.info(f"Inputando valor '{valor}' no campo: {nome_campo}")
    elemento = obter_elemento(page, identificadores_html)
    elemento.click()
    page.keyboard.press("Control+a")
    page.keyboard.press("Delete")
    time.sleep(0.1)
    elemento.type(str(valor), delay=30)
    time.sleep(0.3)

def extrair_texto(page: Page, identificadores_html: list, nome_dado: str = "") -> str:
    """Extrai texto de um elemento na tela."""
    elemento = obter_elemento(page, identificadores_html)
    texto = elemento.inner_text().strip()
    LOG.info(f"Dado extraído ({nome_dado}): {texto}")
    return texto
