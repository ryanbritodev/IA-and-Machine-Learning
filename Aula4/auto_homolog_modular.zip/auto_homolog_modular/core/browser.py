# core/browser.py
from playwright.sync_api import sync_playwright

def iniciar_navegador(headless=False):
    """Inicializa o Playwright e retorna o contexto e a página."""
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=headless, args=["--start-maximized"])
    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    return playwright, browser, context, page
