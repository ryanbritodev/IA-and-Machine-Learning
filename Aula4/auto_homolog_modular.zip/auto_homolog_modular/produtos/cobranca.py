# produtos/cobranca.py
from core.actions import apertar_botao, inputar_valor
from config import SELETORES
from produtos.base import JornadaModular

def bloco_buscar_cnpj(page, dados):
    # Pode reaproveitar blocos!
    inputar_valor(page, SELETORES["CAMPO_BUSCA"], dados["cnpj"], "Busca CNPJ")
    page.keyboard.press("Enter")
    apertar_botao(page, SELETORES["CARD_EMPRESA"], "Card da Empresa")
    apertar_botao(page, SELETORES["BOTAO_CONTINUAR"], "Continuar")

def bloco_selecionar_produto_cobranca(page, dados):
    # Usa um seletor diferente
    apertar_botao(page, SELETORES["PRODUTO_COBRANCA"], "Produto Cobrança")

def configurar_jornada_cobranca(page, dados_linha):
    jornada = JornadaModular(page, dados_linha)
    jornada.adicionar_passo("1. Buscar CNPJ", bloco_buscar_cnpj)
    jornada.adicionar_passo("2. Selecionar Cobrança", bloco_selecionar_produto_cobranca)
    return jornada
