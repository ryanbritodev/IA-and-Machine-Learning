# produtos/desconto.py
from core.actions import apertar_botao, inputar_valor
from config import SELETORES
from produtos.base import JornadaModular

# --- DEFINIÇÃO DOS BLOCOS LÓGICOS ---

def bloco_buscar_cnpj(page, dados):
    inputar_valor(page, SELETORES["CAMPO_BUSCA"], dados["cnpj"], "Busca CNPJ")
    page.keyboard.press("Enter")
    apertar_botao(page, SELETORES["CARD_EMPRESA"], "Card da Empresa")
    apertar_botao(page, SELETORES["BOTAO_CONTINUAR"], "Continuar")

def bloco_selecionar_produto_desconto(page, dados):
    apertar_botao(page, SELETORES["PRODUTO_DESCONTO"], "Produto Desconto")

def bloco_precificar_valor(page, dados):
    inputar_valor(page, SELETORES["CAMPO_VALOR_CLIENTE"], dados["valor"], "Valor do Cliente")
    apertar_botao(page, SELETORES["BOTAO_PRECIFICAR"], "Precificar")

def bloco_adicionar_carrinho(page, dados):
    apertar_botao(page, SELETORES["BOTAO_ADICIONAR_CARRINHO"], "Adicionar ao Carrinho")

# --- MONTAGEM DA JORNADA ---

def configurar_jornada_desconto(page, dados_linha):
    jornada = JornadaModular(page, dados_linha)
    jornada.adicionar_passo("1. Buscar CNPJ", bloco_buscar_cnpj)
    jornada.adicionar_passo("2. Selecionar Desconto", bloco_selecionar_produto_desconto)
    jornada.adicionar_passo("3. Precificar Valor", bloco_precificar_valor)
    jornada.adicionar_passo("4. Adicionar ao Carrinho", bloco_adicionar_carrinho)
    return jornada
