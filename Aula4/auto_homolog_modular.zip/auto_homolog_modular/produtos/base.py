# produtos/base.py
import logging

LOG = logging.getLogger("jornada")

class JornadaModular:
    """
    Motor que executa uma lista de blocos lógicos (passos).
    """
    def __init__(self, page, contexto_dados):
        self.page = page
        self.contexto_dados = contexto_dados
        self.passos = []

    def adicionar_passo(self, nome, funcao):
        self.passos.append((nome, funcao))

    def executar(self):
        for nome, funcao in self.passos:
            LOG.info(f"=== Executando Bloco Lógico: {nome} ===")
            try:
                funcao(self.page, self.contexto_dados)
            except Exception as e:
                LOG.error(f"Falha no bloco '{nome}': {e}")
                raise
